-- Load the items
Tracker:AddItems("Items.json")

-- Load the maps
Tracker:AddMaps("maps.json")

-- Load all the overworld and dungeon locations
Tracker:AddLocations("locations/berugas_lab.json")
Tracker:AddLocations("locations/dragoon_castle.json")
Tracker:AddLocations("locations/eklamata.json")
Tracker:AddLocations("locations/great_cliff.json")
Tracker:AddLocations("locations/great_lakes.json")
Tracker:AddLocations("locations/louran.json")
Tracker:AddLocations("locations/neotokio_sewers.json")
Tracker:AddLocations("locations/overworld.json")
Tracker:AddLocations("locations/overworld_dungeons.json")
Tracker:AddLocations("locations/ra_tree.json")
Tracker:AddLocations("locations/sylvain_castle.json")
Tracker:AddLocations("locations/zue.json")
Tracker:AddLocations("locations/norfest_forest.json")

-- Load the layouts
Tracker:AddLayouts("layouts/item_grid.json")
Tracker:AddLayouts("layouts/tracker.json")
Tracker:AddLayouts("layouts/capture.json")
Tracker:AddLayouts("layouts/broadcast.json")